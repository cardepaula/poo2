
package refeicao;

/**
 *
 * @author felipe
 */
public class HamburgerCarne implements Hamburger {
    
    
    
}
