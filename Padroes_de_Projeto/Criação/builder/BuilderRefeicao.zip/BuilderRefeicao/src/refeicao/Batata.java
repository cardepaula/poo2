
package refeicao;



public class Batata {

    public Batata(){
        System.out.println("cria uma batata.");
    }
}