
Exerc�cio -  Builder - 


Altere o projeto acima e adicione batata como uma op��o para o cliente. Fa�a a altera��o como exibido no diagrama de classe baixo:


![alt text](https://github.com/felipefo/poo2/blob/master/Padroes_de_Projeto/Cria%C3%A7%C3%A3o/builder/BuilderRefeicao/exercicio_refeicao_builder_com_batada.png)

